<script setup>
import Login from './views/login.vue';
</script>

<template>
  <Login />
</template>

<style>
</style>
